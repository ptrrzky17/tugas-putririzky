<?php
class Contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h>Perkenalkan</h1>";
        echo" Nama saya Muhammad Richo
              Saya tinggal di daerah Jakarta Pusat
              Olahraga yang saya sukai adalah
              Bermain Futsal";
              
                    

    }
}