<?php
class Contoh1 extends CI_Controller
{
    public function index()
    {
        echo "<h>Perkenalkan</h1>";
        echo" Nama saya Muhammad Alfaridzi
              Saya tinggal di daerah Jakarta Timur
              Olahraga yang saya sukai adalah
              Bulutangkis,Futsal";

    }
}